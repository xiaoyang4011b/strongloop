--新增回复微博
ALTER TABLE  `onethink_weibo_comment` ADD  `to_comment_id` INT NOT NULL;