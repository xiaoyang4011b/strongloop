<?php
/**
 * 所属项目 OnePlus.
 * 开发者: 想天
 * 创建日期: 3/15/14
 * 创建时间: 5:13 PM
 * 版权所有 想天工作室(www.ourstu.com)
 */

function get_seo_meta_html() {
    //读取SEO规则
    $meta = D('SeoRule')->getMetaOfCurrentPage();

    //添加反斜杠
    $meta['keywords'] = addslashes($meta['keywords']);
    $meta['description'] = addslashes($meta['description']);
    $meta['title'] = htmlspecialchars($meta['title']);
    unset($e);

    //生成seo代码
    return <<< HTML
    <meta name="keywords" content="$meta[content]"/>
    <meta name="description" content="$meta[description]"/>
    <title>$meta[title]</title>
HTML;
}